﻿// Change statement here
var page1_s1 = "page1_s1";
var page1_s2 = "page1_s2";
var page2_s1 = "page2_s1";
var page2_s2 = "page2_s2";
var page3_s1 = "page3_s1";
var page3_s2 = "page3_s2";

var page1_i1 = "page1_image1.png";
var page1_i2 = "page1_image2.png";
var page2_i1 = "page2_image1.png";
var page2_i2 = "page2_image2.png";
var page3_i1 = "page3_image1.png";
var page3_i2 = "page3_image2.png";

document.addEventListener("DOMContentLoaded", function (event) {
    if (document.getElementById("page1_span") != null)
        document.getElementById("page1_span").textContent = page1_s1;
    if (document.getElementById("page2_span") != null)
        document.getElementById("page2_span").textContent = page2_s1;
    if (document.getElementById("page3_span") != null)
        document.getElementById("page3_span").textContent = page3_s1;
});

function togglebutton() {
    // Button toggle
    var btn = document.getElementById("togglebutton");

    btn.classList.toggle('btn-toggle-white');

    if (btn.textContent == "S1") {
        btn.textContent = "S2";
    }
    else {
        btn.textContent = "S1";
    }

    // div 오른쪽 정렬
    var con = document.getElementsByClassName("content1-left");
    // 클래스 이름으로 가져온건 여러개라서 맨 앞에를 골라준다.
    con[0].classList.toggle("content1-right");

    var grey_line = document.getElementsByClassName("grey-line-left");
    grey_line[0].classList.toggle("grey-line-right");

    var text = document.getElementsByClassName("contents1-textbox-label")[0];

    // 문장 토글
    if (text.textContent == page1_s1) {
        text.textContent = page1_s2;
    }
    else if (text.textContent == page1_s2) {
        text.textContent = page1_s1;
    }

    else if (text.textContent == page2_s1) {
        text.textContent = page2_s2;
    }
    else if (text.textContent == page2_s2) {
        text.textContent = page2_s1;
    }

    else if (text.textContent == page3_s2) {
        text.textContent = page3_s1;
    }
    else if (text.textContent == page3_s1) {
        text.textContent = page3_s2;
    }

    // 이미지 토글
    var img = document.getElementById("image");
    var img_src = img.src.split('/')[img.src.split('/').length - 1];

    if (img_src == page1_i1) {
        img.src = "../image/" + page1_i2;
    }
    else if (img_src == page1_i2) {
        img.src = "../image/" + page1_i1;
    }

    else if (img_src == page2_i1) {
        img.src = "../image/" + page2_i2;
    }
    else if (img_src == page2_i2) {
        img.src = "../image/" + page2_i1;
    }

    else if (img_src == page3_i1) {
        img.src = "../image/" + page3_i2;
    }
    else if (img_src == page3_i2) {
        img.src = "../image/" + page3_i1;
    }
}

// 4페이지의 퀴즈가 1번이 정답일 경우. 2번이 정답이면 함수 내부를 서로 바꿔주면 된다.

function click_quiz1_answer1() {

}

function click_quiz1_answer2(){

}

// 4페이지의 퀴즈가 1번이 정답일 경우. 2번이 정답이면 함수 내부를 서로 바꿔주면 된다.



// 5페이지의 퀴즈가 1번이 정답일 경우. 2번이 정답이면 함수 내부를 서로 바꿔주면 된다.

function click_quiz2_answer1() {
}

function click_quiz2_answer2() {

}

// 5페이지의 퀴즈가 1번이 정답일 경우. 2번이 정답이면 함수 내부를 서로 바꿔주면 된다.